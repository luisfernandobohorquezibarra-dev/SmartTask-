# SmartTask Final

Proyecto web funcional de gestion de tareas basado en los requisitos del proyecto SmartTask.

## Como usar

### Opcion 1: abrir directo
1. Descomprime la carpeta.
2. Abre `index.html`.
3. El sistema redirige a login o dashboard.

### Opcion 2: abrir la pagina principal manualmente
- `pages/login.html`

## Acceso demo
- Correo: `demo@smarttask.com`
- Clave: `demo123`

## Funcionalidades
- Registro e inicio de sesion
- Cada usuario solo ve sus propias tareas
- Crear, editar, eliminar y completar tareas
- Prioridades alta, media y baja
- Fecha limite y orden por urgencia
- Categorias estudio, trabajo y personal
- Dashboard con pendientes, completadas y productividad
- Buscador y filtros por estado, prioridad y categoria
- Recordatorios simples para tareas proximas o vencidas
- Diseno responsive
- Persistencia local con localStorage

## Estructura
- `assets/css/styles.css`
- `assets/js/storage.js`
- `assets/js/ui.js`
- `assets/js/auth.js`
- `assets/js/dashboard.js`
- `assets/js/tasks.js`
- `assets/js/task-form.js`
- `pages/login.html`
- `pages/register.html`
- `pages/dashboard.html`
- `pages/tasks.html`
- `pages/task-create.html`
- `pages/task-edit.html`

## Nota
No requiere npm, Vite ni servidor. Funciona directamente en el navegador.
