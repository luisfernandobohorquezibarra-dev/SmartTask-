(function () {
  function renderTaskCard(task) {
    return [
      '<article class="task-card" data-task-id="' + task.id + '">',
      '  <div class="task-top">',
      '    <div>',
      '      <h3 class="task-title">' + window.SmartTaskUI.escapeHtml(task.title) + '</h3>',
      '      <div class="task-meta">',
      '        <span class="badge ' + window.SmartTaskUI.getPriorityClass(task.priority) + '">' + window.SmartTaskUI.escapeHtml(task.priority) + '</span>',
      '        <span class="badge ' + window.SmartTaskUI.getStatusClass(task.status) + '">' + window.SmartTaskUI.escapeHtml(task.status) + '</span>',
      '        <span class="badge category">' + window.SmartTaskUI.escapeHtml(task.category) + '</span>',
      '      </div>',
      '    </div>',
      '    <div class="helper-text">Fecha limite: ' + window.SmartTaskUI.escapeHtml(window.SmartTaskUI.formatDate(task.dueDate)) + '</div>',
      '  </div>',
      (task.description ? '  <p class="task-description">' + window.SmartTaskUI.escapeHtml(task.description) + '</p>' : ''),
      '  <div class="task-actions">',
      '    <a class="button-ghost" href="task-edit.html?id=' + task.id + '">Editar</a>',
      '    <button class="button-secondary js-toggle-task" data-task-id="' + task.id + '">' + (task.status === 'Completada' ? 'Reabrir' : 'Completar') + '</button>',
      '    <button class="button-danger js-delete-task" data-task-id="' + task.id + '">Eliminar</button>',
      '  </div>',
      '</article>'
    ].join('');
  }

  function bindTaskActions(listContainer) {
    listContainer.addEventListener('click', function (event) {
      const deleteButton = event.target.closest('.js-delete-task');
      const toggleButton = event.target.closest('.js-toggle-task');

      if (deleteButton) {
        const taskId = deleteButton.getAttribute('data-task-id');
        const confirmed = window.confirm('Deseas eliminar esta tarea?');
        if (!confirmed) return;
        window.SmartTaskStorage.deleteTask(taskId);
        initTasksPage();
        return;
      }

      if (toggleButton) {
        const taskId = toggleButton.getAttribute('data-task-id');
        window.SmartTaskStorage.toggleTaskStatus(taskId);
        initTasksPage();
      }
    });
  }

  function initTasksPage() {
    window.SmartTaskUI.mountAppFrame({ active: 'tasks' });
    const user = window.SmartTaskUI.requireAuth();
    if (!user) return;

    const container = document.getElementById('pageContent');
    if (!container) return;

    container.innerHTML = [
      window.SmartTaskUI.renderPageHeader(
        'Lista de tareas',
        'Consulta, filtra, busca y administra tus tareas.',
        '<a class="button" href="task-create.html">Crear tarea</a>'
      ),
      '<section class="card section-card">',
      '  <div class="section-head">',
      '    <div>',
      '      <h2>Filtros y buscador</h2>',
      '      <p>Filtra por estado, prioridad, categoria y busqueda por texto.</p>',
      '    </div>',
      '  </div>',
      '  <div class="filters">',
      '    <input id="searchInput" type="text" placeholder="Buscar por titulo o descripcion">',
      '    <select id="statusFilter"><option value="">Todos los estados</option><option value="Pendiente">Pendiente</option><option value="Completada">Completada</option></select>',
      '    <select id="priorityFilter"><option value="">Todas las prioridades</option><option value="Alta">Alta</option><option value="Media">Media</option><option value="Baja">Baja</option></select>',
      '    <select id="categoryFilter"><option value="">Todas las categorias</option><option value="Estudio">Estudio</option><option value="Trabajo">Trabajo</option><option value="Personal">Personal</option></select>',
      '  </div>',
      '</section>',
      '<section class="card section-card" style="margin-top:20px;">',
      '  <div class="section-head">',
      '    <div>',
      '      <h2>Mis tareas</h2>',
      '      <p>Orden automatico por fecha limite.</p>',
      '    </div>',
      '  </div>',
      '  <div id="taskList" class="task-list"></div>',
      '</section>'
    ].join('');

    const allTasks = window.SmartTaskUI.sortTasksByUrgency(window.SmartTaskStorage.getTasksByUser(user.id));
    const taskList = document.getElementById('taskList');
    const searchInput = document.getElementById('searchInput');
    const statusFilter = document.getElementById('statusFilter');
    const priorityFilter = document.getElementById('priorityFilter');
    const categoryFilter = document.getElementById('categoryFilter');

    function applyFilters() {
      const search = String(searchInput.value || '').trim().toLowerCase();
      const status = statusFilter.value;
      const priority = priorityFilter.value;
      const category = categoryFilter.value;

      const filtered = allTasks.filter(function (task) {
        const matchesSearch = !search || task.title.toLowerCase().includes(search) || String(task.description || '').toLowerCase().includes(search);
        const matchesStatus = !status || task.status === status;
        const matchesPriority = !priority || task.priority === priority;
        const matchesCategory = !category || task.category === category;
        return matchesSearch && matchesStatus && matchesPriority && matchesCategory;
      });

      if (!filtered.length) {
        taskList.innerHTML = '<div class="empty-state"><h3>No hay resultados</h3><p>Ajusta los filtros o crea una nueva tarea.</p></div>';
        return;
      }

      taskList.innerHTML = filtered.map(renderTaskCard).join('');
    }

    [searchInput, statusFilter, priorityFilter, categoryFilter].forEach(function (element) {
      element.addEventListener('input', applyFilters);
      element.addEventListener('change', applyFilters);
    });

    bindTaskActions(taskList);
    applyFilters();
  }

  window.SmartTaskTasks = {
    initTasksPage: initTasksPage
  };
})();
