(function () {
  function ensureBootstrap() {
    if (window.SmartTaskStorage) {
      window.SmartTaskStorage.bootstrap();
    }
  }

  function requireAuth() {
    ensureBootstrap();
    const user = window.SmartTaskStorage.getCurrentUser();
    if (!user) {
      window.location.href = 'login.html';
      return null;
    }
    return user;
  }

  function logout() {
    window.SmartTaskStorage.clearSession();
    window.location.href = 'login.html';
  }

  function formatDate(dateString) {
    if (!dateString) {
      return 'Sin fecha';
    }

    const date = new Date(dateString + 'T00:00:00');
    if (Number.isNaN(date.getTime())) {
      return dateString;
    }

    return date.toLocaleDateString('es-CO', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  }

  function getPriorityClass(priority) {
    if (priority === 'Alta') return 'priority-high';
    if (priority === 'Media') return 'priority-medium';
    return 'priority-low';
  }

  function getStatusClass(status) {
    return status === 'Completada' ? 'status-completed' : 'status-pending';
  }

  function sortTasksByUrgency(tasks) {
    return tasks.slice().sort(function (a, b) {
      if (!a.dueDate && !b.dueDate) return 0;
      if (!a.dueDate) return 1;
      if (!b.dueDate) return -1;
      return new Date(a.dueDate) - new Date(b.dueDate);
    });
  }

  function getDaysDiff(dateString) {
    if (!dateString) return null;
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    const date = new Date(dateString + 'T00:00:00');
    if (Number.isNaN(date.getTime())) return null;
    return Math.round((date - today) / 86400000);
  }

  function escapeHtml(value) {
    return String(value)
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function showAlert(element, type, message) {
    if (!element) return;
    element.className = 'alert show ' + type;
    element.textContent = message;
  }

  function clearAlert(element) {
    if (!element) return;
    element.className = 'alert';
    element.textContent = '';
  }

  function mountAppFrame(options) {
    const root = document.getElementById('app');
    if (!root) return;

    const user = requireAuth();
    if (!user) return;

    const active = options && options.active ? options.active : 'dashboard';

    root.innerHTML = [
      '<div class="app-shell">',
      '  <aside class="sidebar">',
      '    <div class="brand">',
      '      <span class="brand-mark">ST</span>',
      '      <div>',
      '        <div>SmartTask</div>',
      '        <small>Gestor de tareas</small>',
      '      </div>',
      '    </div>',
      '    <div class="user-box">',
      '      <small>Sesion activa</small>',
      '      <strong>' + escapeHtml(user.name) + '</strong>',
      '      <small>' + escapeHtml(user.email) + '</small>',
      '    </div>',
      '    <nav class="nav-menu">',
      '      <a class="nav-link ' + (active === 'dashboard' ? 'active' : '') + '" href="dashboard.html">Dashboard</a>',
      '      <a class="nav-link ' + (active === 'tasks' ? 'active' : '') + '" href="tasks.html">Lista de tareas</a>',
      '      <a class="nav-link ' + (active === 'create' ? 'active' : '') + '" href="task-create.html">Crear tarea</a>',
      '      <a class="nav-link ' + (active === 'edit' ? 'active' : '') + '" href="task-edit.html">Editar tarea</a>',
      '    </nav>',
      '    <button id="logoutButton" class="button logout-button">Cerrar sesion</button>',
      '    <p class="footer-note">Cada usuario solo visualiza sus tareas, con filtros, prioridades y seguimiento.</p>',
      '  </aside>',
      '  <main class="main-area">',
      '    <div id="pageContent"></div>',
      '  </main>',
      '</div>'
    ].join('');

    const logoutButton = document.getElementById('logoutButton');
    if (logoutButton) {
      logoutButton.addEventListener('click', logout);
    }
  }

  function renderPageHeader(title, subtitle, actionsHtml) {
    return [
      '<div class="topbar">',
      '  <div>',
      '    <h1>' + escapeHtml(title) + '</h1>',
      '    <p>' + escapeHtml(subtitle) + '</p>',
      '  </div>',
      '  <div class="topbar-actions">' + (actionsHtml || '') + '</div>',
      '</div>'
    ].join('');
  }

  window.SmartTaskUI = {
    requireAuth: requireAuth,
    logout: logout,
    formatDate: formatDate,
    getPriorityClass: getPriorityClass,
    getStatusClass: getStatusClass,
    sortTasksByUrgency: sortTasksByUrgency,
    getDaysDiff: getDaysDiff,
    escapeHtml: escapeHtml,
    showAlert: showAlert,
    clearAlert: clearAlert,
    mountAppFrame: mountAppFrame,
    renderPageHeader: renderPageHeader
  };
})();
