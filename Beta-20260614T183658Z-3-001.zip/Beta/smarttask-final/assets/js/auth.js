(function () {
  function initAuthPage(config) {
    if (!window.SmartTaskStorage || !window.SmartTaskUI) return;
    window.SmartTaskStorage.bootstrap();

    const currentUser = window.SmartTaskStorage.getCurrentUser();
    if (currentUser) {
      window.location.href = 'dashboard.html';
      return;
    }

    const form = document.getElementById(config.formId);
    const alertBox = document.getElementById('formAlert');

    if (!form) return;

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      window.SmartTaskUI.clearAlert(alertBox);

      const data = new FormData(form);

      if (config.type === 'login') {
        const result = window.SmartTaskStorage.login(data.get('email'), data.get('password'));
        if (!result.ok) {
          window.SmartTaskUI.showAlert(alertBox, 'error', result.message);
          return;
        }
        window.location.href = 'dashboard.html';
        return;
      }

      const name = String(data.get('name') || '').trim();
      const email = String(data.get('email') || '').trim();
      const password = String(data.get('password') || '');
      const confirmPassword = String(data.get('confirmPassword') || '');

      if (!name || !email || !password) {
        window.SmartTaskUI.showAlert(alertBox, 'error', 'Completa todos los campos obligatorios.');
        return;
      }

      if (password.length < 6) {
        window.SmartTaskUI.showAlert(alertBox, 'error', 'La contrasena debe tener minimo 6 caracteres.');
        return;
      }

      if (password !== confirmPassword) {
        window.SmartTaskUI.showAlert(alertBox, 'error', 'La confirmacion de contrasena no coincide.');
        return;
      }

      const result = window.SmartTaskStorage.registerUser({
        name: name,
        email: email,
        password: password
      });

      if (!result.ok) {
        window.SmartTaskUI.showAlert(alertBox, 'error', result.message);
        return;
      }

      window.location.href = 'dashboard.html';
    });
  }

  window.SmartTaskAuth = {
    initAuthPage: initAuthPage
  };
})();
