(function () {
  function getTaskIdFromUrl() {
    const params = new URLSearchParams(window.location.search);
    return params.get('id');
  }

  function buildFormHtml(title, subtitle, submitText, cancelLink) {
    return [
      window.SmartTaskUI.renderPageHeader(title, subtitle, cancelLink ? '<a class="button-ghost" href="' + cancelLink + '">Cancelar</a>' : ''),
      '<section class="card section-card">',
      '  <div id="formAlert" class="alert"></div>',
      '  <form id="taskForm" class="form-grid">',
      '    <div class="field">',
      '      <label for="title">Titulo *</label>',
      '      <input id="title" name="title" type="text" maxlength="120" placeholder="Ejemplo: Entregar avance del proyecto">',
      '    </div>',
      '    <div class="field">',
      '      <label for="description">Descripcion</label>',
      '      <textarea id="description" name="description" placeholder="Describe la tarea, observaciones o pasos clave."></textarea>',
      '    </div>',
      '    <div class="row-3">',
      '      <div class="field">',
      '        <label for="category">Categoria</label>',
      '        <select id="category" name="category">',
      '          <option value="Estudio">Estudio</option>',
      '          <option value="Trabajo">Trabajo</option>',
      '          <option value="Personal">Personal</option>',
      '        </select>',
      '      </div>',
      '      <div class="field">',
      '        <label for="priority">Prioridad</label>',
      '        <select id="priority" name="priority">',
      '          <option value="Alta">Alta</option>',
      '          <option value="Media" selected>Media</option>',
      '          <option value="Baja">Baja</option>',
      '        </select>',
      '      </div>',
      '      <div class="field">',
      '        <label for="dueDate">Fecha limite</label>',
      '        <input id="dueDate" name="dueDate" type="date">',
      '      </div>',
      '    </div>',
      '    <div class="row">',
      '      <div class="field">',
      '        <label for="status">Estado</label>',
      '        <select id="status" name="status">',
      '          <option value="Pendiente">Pendiente</option>',
      '          <option value="Completada">Completada</option>',
      '        </select>',
      '      </div>',
      '      <div class="field">',
      '        <label>Recordatorio</label>',
      '        <div class="notice">Las tareas se muestran como recordatorio simple cuando estan proximas a vencer o vencidas.</div>',
      '      </div>',
      '    </div>',
      '    <div class="task-actions">',
      '      <button class="button" type="submit">' + submitText + '</button>',
      '      <a class="button-secondary" href="tasks.html">Volver a tareas</a>',
      '    </div>',
      '  </form>',
      '</section>'
    ].join('');
  }

  function initCreatePage() {
    window.SmartTaskUI.mountAppFrame({ active: 'create' });
    const user = window.SmartTaskUI.requireAuth();
    if (!user) return;

    const container = document.getElementById('pageContent');
    if (!container) return;

    container.innerHTML = buildFormHtml('Crear tarea', 'Registra una nueva tarea con prioridad, categoria y fecha limite.', 'Guardar tarea', 'tasks.html');
    bindForm('create', user);
  }

  function initEditPage() {
    window.SmartTaskUI.mountAppFrame({ active: 'edit' });
    const user = window.SmartTaskUI.requireAuth();
    if (!user) return;

    const container = document.getElementById('pageContent');
    if (!container) return;

    const taskId = getTaskIdFromUrl();
    const task = taskId ? window.SmartTaskStorage.getTaskById(taskId) : null;

    if (!task || task.userId !== user.id) {
      container.innerHTML = [
        window.SmartTaskUI.renderPageHeader('Editar tarea', 'No fue posible cargar la tarea solicitada.', '<a class="button-ghost" href="tasks.html">Volver</a>'),
        '<section class="card section-card">',
        '  <div class="empty-state"><h3>Tarea no encontrada</h3><p>Selecciona una tarea valida desde la lista para editarla.</p></div>',
        '</section>'
      ].join('');
      return;
    }

    container.innerHTML = buildFormHtml('Editar tarea', 'Actualiza la informacion de la tarea seleccionada.', 'Guardar cambios', 'tasks.html');
    bindForm('edit', user, task);
  }

  function bindForm(mode, user, task) {
    const form = document.getElementById('taskForm');
    const alertBox = document.getElementById('formAlert');
    if (!form) return;

    if (task) {
      form.title.value = task.title || '';
      form.description.value = task.description || '';
      form.category.value = task.category || 'Estudio';
      form.priority.value = task.priority || 'Media';
      form.dueDate.value = task.dueDate || '';
      form.status.value = task.status || 'Pendiente';
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      window.SmartTaskUI.clearAlert(alertBox);

      const data = new FormData(form);
      const title = String(data.get('title') || '').trim();

      if (!title) {
        window.SmartTaskUI.showAlert(alertBox, 'error', 'No se permite crear o guardar tareas sin titulo.');
        return;
      }

      const payload = {
        userId: user.id,
        title: title,
        description: String(data.get('description') || '').trim(),
        category: String(data.get('category') || 'Personal'),
        priority: String(data.get('priority') || 'Media'),
        status: String(data.get('status') || 'Pendiente'),
        dueDate: String(data.get('dueDate') || '')
      };

      if (mode === 'create') {
        window.SmartTaskStorage.createTask(payload);
        window.location.href = 'tasks.html';
        return;
      }

      window.SmartTaskStorage.updateTask(task.id, payload);
      window.location.href = 'tasks.html';
    });
  }

  window.SmartTaskForms = {
    initCreatePage: initCreatePage,
    initEditPage: initEditPage
  };
})();
