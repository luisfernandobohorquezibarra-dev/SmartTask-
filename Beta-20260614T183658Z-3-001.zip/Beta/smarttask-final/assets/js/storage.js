(function () {
  const USERS_KEY = 'smarttask_users';
  const TASKS_KEY = 'smarttask_tasks';
  const SESSION_KEY = 'smarttask_session';

  function read(key, fallback) {
    try {
      const value = localStorage.getItem(key);
      return value ? JSON.parse(value) : fallback;
    } catch (error) {
      return fallback;
    }
  }

  function write(key, value) {
    localStorage.setItem(key, JSON.stringify(value));
  }

  function createId(prefix) {
    return prefix + '_' + Date.now() + '_' + Math.random().toString(36).slice(2, 9);
  }

  function normalizeEmail(email) {
    return String(email || '').trim().toLowerCase();
  }

  function bootstrap() {
    const users = read(USERS_KEY, []);
    const tasks = read(TASKS_KEY, []);

    if (!users.length) {
      const demoUserId = createId('user');
      const demoUser = {
        id: demoUserId,
        name: 'Usuario Demo',
        email: 'demo@smarttask.com',
        password: 'demo123',
        createdAt: new Date().toISOString()
      };

      const now = new Date();
      const tomorrow = new Date(now);
      tomorrow.setDate(now.getDate() + 1);
      const nextWeek = new Date(now);
      nextWeek.setDate(now.getDate() + 7);

      const seededTasks = [
        {
          id: createId('task'),
          userId: demoUserId,
          title: 'Entregar actividad de analisis de requerimientos',
          description: 'Revisar el documento, completar observaciones y subir la evidencia final.',
          category: 'Estudio',
          priority: 'Alta',
          status: 'Pendiente',
          dueDate: now.toISOString().slice(0, 10),
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        },
        {
          id: createId('task'),
          userId: demoUserId,
          title: 'Actualizar tablero del proyecto SmartTask',
          description: 'Registrar avances del sprint y validar modulos pendientes.',
          category: 'Trabajo',
          priority: 'Media',
          status: 'Pendiente',
          dueDate: tomorrow.toISOString().slice(0, 10),
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        },
        {
          id: createId('task'),
          userId: demoUserId,
          title: 'Revisar tareas personales de la semana',
          description: 'Organizar actividades del fin de semana y cerrar pendientes.',
          category: 'Personal',
          priority: 'Baja',
          status: 'Completada',
          dueDate: nextWeek.toISOString().slice(0, 10),
          createdAt: now.toISOString(),
          updatedAt: now.toISOString()
        }
      ];

      write(USERS_KEY, [demoUser]);
      write(TASKS_KEY, seededTasks);
      return;
    }

    if (!Array.isArray(tasks)) {
      write(TASKS_KEY, []);
    }
  }

  function getUsers() {
    return read(USERS_KEY, []);
  }

  function saveUsers(users) {
    write(USERS_KEY, users);
  }

  function getTasks() {
    return read(TASKS_KEY, []);
  }

  function saveTasks(tasks) {
    write(TASKS_KEY, tasks);
  }

  function getSession() {
    return read(SESSION_KEY, null);
  }

  function setSession(userId) {
    write(SESSION_KEY, { userId: userId, createdAt: new Date().toISOString() });
  }

  function clearSession() {
    localStorage.removeItem(SESSION_KEY);
  }

  function getCurrentUser() {
    const session = getSession();
    if (!session || !session.userId) {
      return null;
    }
    return getUsers().find(function (user) {
      return user.id === session.userId;
    }) || null;
  }

  function registerUser(payload) {
    const users = getUsers();
    const email = normalizeEmail(payload.email);

    const exists = users.some(function (user) {
      return normalizeEmail(user.email) === email;
    });

    if (exists) {
      return { ok: false, message: 'Ya existe una cuenta registrada con ese correo.' };
    }

    const user = {
      id: createId('user'),
      name: String(payload.name || '').trim(),
      email: email,
      password: String(payload.password || ''),
      createdAt: new Date().toISOString()
    };

    users.push(user);
    saveUsers(users);
    setSession(user.id);
    return { ok: true, user: user };
  }

  function login(email, password) {
    const normalizedEmail = normalizeEmail(email);
    const user = getUsers().find(function (item) {
      return normalizeEmail(item.email) === normalizedEmail && item.password === String(password || '');
    });

    if (!user) {
      return { ok: false, message: 'Correo o contrasena incorrectos.' };
    }

    setSession(user.id);
    return { ok: true, user: user };
  }

  function getTasksByUser(userId) {
    return getTasks().filter(function (task) {
      return task.userId === userId;
    });
  }

  function createTask(payload) {
    const tasks = getTasks();
    const task = {
      id: createId('task'),
      userId: payload.userId,
      title: String(payload.title || '').trim(),
      description: String(payload.description || '').trim(),
      category: payload.category || 'Personal',
      priority: payload.priority || 'Media',
      status: payload.status || 'Pendiente',
      dueDate: payload.dueDate || '',
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString()
    };

    tasks.push(task);
    saveTasks(tasks);
    return task;
  }

  function updateTask(taskId, payload) {
    const tasks = getTasks();
    const index = tasks.findIndex(function (task) {
      return task.id === taskId;
    });

    if (index === -1) {
      return null;
    }

    tasks[index] = Object.assign({}, tasks[index], payload, {
      title: String(payload.title || tasks[index].title || '').trim(),
      description: String(payload.description || '').trim(),
      updatedAt: new Date().toISOString()
    });

    saveTasks(tasks);
    return tasks[index];
  }

  function deleteTask(taskId) {
    const tasks = getTasks().filter(function (task) {
      return task.id !== taskId;
    });
    saveTasks(tasks);
  }

  function getTaskById(taskId) {
    return getTasks().find(function (task) {
      return task.id === taskId;
    }) || null;
  }

  function toggleTaskStatus(taskId) {
    const task = getTaskById(taskId);
    if (!task) {
      return null;
    }
    const newStatus = task.status === 'Completada' ? 'Pendiente' : 'Completada';
    return updateTask(taskId, { status: newStatus });
  }

  window.SmartTaskStorage = {
    bootstrap: bootstrap,
    getUsers: getUsers,
    getTasks: getTasks,
    getCurrentUser: getCurrentUser,
    getSession: getSession,
    clearSession: clearSession,
    registerUser: registerUser,
    login: login,
    getTasksByUser: getTasksByUser,
    createTask: createTask,
    updateTask: updateTask,
    deleteTask: deleteTask,
    getTaskById: getTaskById,
    toggleTaskStatus: toggleTaskStatus
  };
})();
