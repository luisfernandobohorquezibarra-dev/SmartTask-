(function () {
  function buildReminder(task) {
    const days = window.SmartTaskUI.getDaysDiff(task.dueDate);
    let text = 'Sin fecha limite';
    let overdue = false;

    if (days !== null) {
      if (days < 0) {
        text = 'Vencida hace ' + Math.abs(days) + ' dia(s).';
        overdue = true;
      } else if (days === 0) {
        text = 'Vence hoy.';
      } else if (days === 1) {
        text = 'Vence manana.';
      } else {
        text = 'Vence en ' + days + ' dia(s).';
      }
    }

    return { text: text, overdue: overdue };
  }

  function initDashboard() {
    window.SmartTaskUI.mountAppFrame({ active: 'dashboard' });
    const user = window.SmartTaskUI.requireAuth();
    if (!user) return;

    const container = document.getElementById('pageContent');
    if (!container) return;

    const tasks = window.SmartTaskUI.sortTasksByUrgency(window.SmartTaskStorage.getTasksByUser(user.id));
    const pending = tasks.filter(function (task) { return task.status === 'Pendiente'; });
    const completed = tasks.filter(function (task) { return task.status === 'Completada'; });
    const productivity = tasks.length ? Math.round((completed.length / tasks.length) * 100) : 0;
    const urgent = pending.filter(function (task) {
      const diff = window.SmartTaskUI.getDaysDiff(task.dueDate);
      return diff !== null && diff <= 2;
    });

    const remindersHtml = urgent.length
      ? urgent.map(function (task) {
          const reminder = buildReminder(task);
          return [
            '<div class="reminder-item ' + (reminder.overdue ? 'overdue' : '') + '">',
            '  <strong>' + window.SmartTaskUI.escapeHtml(task.title) + '</strong>',
            '  <div class="helper-text">' + window.SmartTaskUI.escapeHtml(reminder.text) + '</div>',
            '  <div class="helper-text">Prioridad: ' + window.SmartTaskUI.escapeHtml(task.priority) + ' · Fecha: ' + window.SmartTaskUI.escapeHtml(window.SmartTaskUI.formatDate(task.dueDate)) + '</div>',
            '</div>'
          ].join('');
        }).join('')
      : '<div class="empty-state"><h3>Sin alertas inmediatas</h3><p>No hay tareas urgentes o vencidas para mostrar recordatorios simples.</p></div>';

    const summaryHtml = tasks.length
      ? tasks.slice(0, 5).map(function (task) {
          return [
            '<div class="summary-item">',
            '  <strong>' + window.SmartTaskUI.escapeHtml(task.title) + '</strong>',
            '  <div class="task-meta">',
            '    <span class="badge ' + window.SmartTaskUI.getPriorityClass(task.priority) + '">' + window.SmartTaskUI.escapeHtml(task.priority) + '</span>',
            '    <span class="badge ' + window.SmartTaskUI.getStatusClass(task.status) + '">' + window.SmartTaskUI.escapeHtml(task.status) + '</span>',
            '    <span class="badge category">' + window.SmartTaskUI.escapeHtml(task.category) + '</span>',
            '  </div>',
            '  <div class="helper-text" style="margin-top:10px;">Fecha limite: ' + window.SmartTaskUI.escapeHtml(window.SmartTaskUI.formatDate(task.dueDate)) + '</div>',
            '</div>'
          ].join('');
        }).join('')
      : '<div class="empty-state"><h3>Aun no tienes tareas</h3><p>Crea la primera tarea para comenzar a medir tu productividad.</p></div>';

    container.innerHTML = [
      window.SmartTaskUI.renderPageHeader(
        'Dashboard',
        'Resumen de tareas, productividad y recordatorios simples.',
        '<a class="button" href="task-create.html">Nueva tarea</a><a class="button-ghost" href="tasks.html">Ver lista</a>'
      ),
      '<div class="grid grid-3">',
      '  <section class="card stat-card">',
      '    <div class="stat-label">Tareas pendientes</div>',
      '    <div class="stat-value">' + pending.length + '</div>',
      '    <div class="stat-help">Actividades aun por completar.</div>',
      '  </section>',
      '  <section class="card stat-card">',
      '    <div class="stat-label">Tareas completadas</div>',
      '    <div class="stat-value">' + completed.length + '</div>',
      '    <div class="stat-help">Tareas finalizadas por el usuario.</div>',
      '  </section>',
      '  <section class="card stat-card">',
      '    <div class="stat-label">Productividad</div>',
      '    <div class="stat-value">' + productivity + '%</div>',
      '    <div class="progress"><span style="width:' + productivity + '%"></span></div>',
      '  </section>',
      '</div>',
      '<div class="grid grid-2" style="margin-top:20px;">',
      '  <section class="card section-card">',
      '    <div class="section-head">',
      '      <div><h2>Recordatorios simples</h2><p>Tareas urgentes, proximas o vencidas.</p></div>',
      '    </div>',
      '    <div class="reminder-list">' + remindersHtml + '</div>',
      '  </section>',
      '  <section class="card section-card">',
      '    <div class="section-head">',
      '      <div><h2>Resumen por urgencia</h2><p>Ordenado automaticamente por fecha limite.</p></div>',
      '    </div>',
      '    <div class="summary-list">' + summaryHtml + '</div>',
      '  </section>',
      '</div>'
    ].join('');
  }

  window.SmartTaskDashboard = {
    initDashboard: initDashboard
  };
})();
